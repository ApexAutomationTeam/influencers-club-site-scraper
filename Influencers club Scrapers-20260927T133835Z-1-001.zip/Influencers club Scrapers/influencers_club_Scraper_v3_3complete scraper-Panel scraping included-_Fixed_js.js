
(async () => {
  // ─────────────────────────────────────────────────────────────────────────
  //  CONFIG
  // ─────────────────────────────────────────────────────────────────────────
  const MAX_ROWS        = 50;
  const CLICK_DELAY     = 700;   // ms between rows
  const SCROLL_WAIT     = 300;   // ms after scrollIntoView before clicking
  const PANEL_OPEN_WAIT = 900;   // fixed wait after click (panel animation)
  const PANEL_CLOSE_WAIT= 700;   // fixed wait after Escape / close button
  const SOCIAL_TIMEOUT  = 4000;  // wait for IG/TT links to appear in panel
  const SHEETJS_CDN     = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";
  const RESUME_KEY      = "influencer_scraper_v3_resume";

  // ─────────────────────────────────────────────────────────────────────────
  //  UTILITIES
  // ─────────────────────────────────────────────────────────────────────────
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const log = (msg, type = "info") => {
    const styles = {
      info:     "color:#4fc3f7;font-weight:bold",
      success:  "color:#81c784;font-weight:bold",
      warn:     "color:#ffb74d;font-weight:bold",
      error:    "color:#e57373;font-weight:bold",
      progress: "color:#ce93d8;font-weight:bold",
    };
    console.log(`%c[Scraper] ${msg}`, styles[type] || styles.info);
  };

  // MutationObserver-based wait
  const waitForMutation = (conditionFn, timeout) =>
    new Promise((resolve, reject) => {
      if (conditionFn()) { resolve(); return; }
      let done = false;
      const timer = setTimeout(() => {
        if (done) return;
        done = true;
        observer.disconnect();
        reject(new Error(`waitForMutation timed out after ${timeout}ms`));
      }, timeout);
      const observer = new MutationObserver(() => {
        if (done || !conditionFn()) return;
        done = true;
        clearTimeout(timer);
        observer.disconnect();
        resolve();
      });
      observer.observe(document.body, {
        subtree: true, childList: true, attributes: true, characterData: true,
      });
    });

  const loadSheetJS = () =>
    new Promise((resolve, reject) => {
      if (typeof XLSX !== "undefined") { resolve(); return; }
      log("Loading SheetJS from CDN…");
      const s = document.createElement("script");
      s.src = SHEETJS_CDN;
      s.onload  = () => { log("SheetJS loaded.", "success"); resolve(); };
      s.onerror = () => reject(new Error("Failed to load SheetJS."));
      document.head.appendChild(s);
    });

  // ─────────────────────────────────────────────────────────────────────────
  //  ✅ FIX 1 — COLUMN DETECTION
  //  Bug: h.includes("er") matched "follow[er]s" → both columns = 2
  //  Fix: word-boundary regex \ber\b so only exact "er" word matches
  // ─────────────────────────────────────────────────────────────────────────
  const detectColumnIndices = () => {
    const thEls = document.querySelectorAll("thead th");
    if (!thEls.length) {
      log("No thead — fallback followers=2 engagement=4.", "warn");
      return { followersIdx: 2, engagementIdx: 4 };
    }
    const headers = Array.from(thEls).map((th) => th.innerText.trim().toLowerCase());
    log(`Headers: [${headers.join(" | ")}]`);

    const fi = headers.findIndex(
      (h) => h.includes("follower") || h.includes("fans") || h.includes("subscriber")
    );
    // ★ FIX: \ber\b so "followers" does NOT match
    const ei = headers.findIndex(
      (h) => h.includes("engagement") || h.includes("eng rate") || h.includes("eng.") || h === "er" || /\ber\b/.test(h)
    );

    const followersIdx  = fi !== -1 ? fi : 2;
    const engagementIdx = ei !== -1 ? ei : 4;
    log(`Columns → Followers: ${followersIdx}, Engagement: ${engagementIdx}`);
    return { followersIdx, engagementIdx };
  };

  // ─────────────────────────────────────────────────────────────────────────
  //  CLOSE PANEL — Escape key (primary) + X button (fallback)
  //  ✅ FIX 2: No longer uses isPanelOpen() — just fire close signals & wait
  // ─────────────────────────────────────────────────────────────────────────
  const findCloseButton = () => {
    // Style-based: absolute positioned button near top
    for (const btn of document.querySelectorAll("button")) {
      const s = btn.style;
      if (s.position === "absolute" && (s.top === "12px" || parseInt(s.top) === 12)) return btn;
    }
    for (const el of document.querySelectorAll("button, [role='button']")) {
      const cs = window.getComputedStyle(el);
      if (cs.position === "absolute" && parseInt(cs.top) <= 20 && parseInt(cs.top) >= 4) return el;
    }
    // SVG X-path fallback (close icon)
    for (const btn of document.querySelectorAll("button")) {
      const svg = btn.querySelector("svg");
      if (svg && btn.getBoundingClientRect().width < 50) return btn;
    }
    return null;
  };

  const closePanel = async () => {
    // Primary: Escape key — works for any modal/drawer
    document.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Escape", code: "Escape", keyCode: 27, bubbles: true, cancelable: true,
    }));
    await sleep(PANEL_CLOSE_WAIT);
    // Fallback: click X button if still visible
    const btn = findCloseButton();
    if (btn) {
      btn.click();
      await sleep(400);
    }
  };

  // ─────────────────────────────────────────────────────────────────────────
  //  URL NORMALIZATION
  // ─────────────────────────────────────────────────────────────────────────
  const normalizeURL = (raw) => {
    if (!raw) return "";
    try {
      const u    = new URL(raw.trim());
      const path = decodeURIComponent(u.pathname).replace(/\/+/g, "/").replace(/\/$/, "");
      return `${u.origin}${path}`;
    } catch (_) { return raw.trim(); }
  };

  const extractUsername = (url, platform) => {
    if (!url) return "";
    try {
      const path = decodeURIComponent(new URL(url).pathname);
      let u = path.replace(/\/+/g, "").trim();
      if (platform === "tiktok") u = u.replace(/^@+/, "");
      return u;
    } catch (_) { return ""; }
  };

  // ─────────────────────────────────────────────────────────────────────────
  //  SCRAPE PANEL
  //  Waits up to SOCIAL_TIMEOUT for IG/TT links to appear.
  //  If none → returns empty (valid, not an error).
  // ─────────────────────────────────────────────────────────────────────────
  const scrapePanel = async () => {
    const findIg = () =>
      document.querySelector('a[title="Instagram"]') ||
      document.querySelector('a[href*="instagram.com"]');
    const findTt = () =>
      document.querySelector('a[title="TikTok"]') ||
      document.querySelector('a[href*="tiktok.com"]');

    try {
      await waitForMutation(() => findIg() || findTt(), SOCIAL_TIMEOUT);
    } catch (_) {
      log("No social links in panel — skipping.", "warn");
      return { instagramURL: "", instagramUsername: "", tiktokURL: "", tiktokUsername: "" };
    }

    const igEl = findIg();
    const ttEl = findTt();
    const instagramURL      = normalizeURL(igEl ? igEl.href : "");
    const tiktokURL         = normalizeURL(ttEl ? ttEl.href : "");
    const instagramUsername = extractUsername(instagramURL, "instagram");
    const tiktokUsername    = extractUsername(tiktokURL, "tiktok");

    return { instagramURL, instagramUsername, tiktokURL, tiktokUsername };
  };

  // ─────────────────────────────────────────────────────────────────────────
  //  HTML DUMP on failure
  // ─────────────────────────────────────────────────────────────────────────
  const dumpPanelHTML = (rowIdx) => {
    const panel =
      document.querySelector(".MuiDrawer-paper") ||
      document.querySelector('[role="presentation"]') ||
      document.body;
    console.groupCollapsed(`%c[Scraper] HTML Dump — Row ${rowIdx}`, "color:#ff8a65;font-weight:bold");
    console.log(panel.innerHTML.slice(0, 3000));
    console.groupEnd();
  };

  // ─────────────────────────────────────────────────────────────────────────
  //  ROW META
  // ─────────────────────────────────────────────────────────────────────────
  const scrapeRowMeta = (row, followersIdx, engagementIdx) => {
    const nameEl      = row.querySelector(".creator-name");
    const creatorName = nameEl ? nameEl.innerText.trim() : "";
    const firstP      = row.querySelector("p");
    const location    = firstP ? firstP.innerText.trim() : "";
    const followers   = row.children[followersIdx]  ? row.children[followersIdx].innerText.trim()  : "";
    const engagement  = row.children[engagementIdx] ? row.children[engagementIdx].innerText.trim() : "";
    return { creatorName, location, followers, engagement };
  };

  // ─────────────────────────────────────────────────────────────────────────
  //  INFINITE SCROLL
  // ─────────────────────────────────────────────────────────────────────────
  const tryLoadMoreRows = async (targetCount) => {
    let prev = document.querySelectorAll("tbody tr").length;
    let staleTicks = 0;
    for (let a = 0; a < 10; a++) {
      if (prev >= targetCount) break;
      const last = document.querySelector("tbody tr:last-child");
      if (last) last.scrollIntoView({ block: "end", behavior: "smooth" });
      await sleep(1500);
      const cur = document.querySelectorAll("tbody tr").length;
      if (cur === prev) { if (++staleTicks >= 3) break; }
      else { staleTicks = 0; log(`Scroll-load: ${cur} rows…`); }
      prev = cur;
    }
    return document.querySelectorAll("tbody tr").length;
  };

  // ─────────────────────────────────────────────────────────────────────────
  //  SAFE FILENAME
  // ─────────────────────────────────────────────────────────────────────────
  const safeTimestamp = () =>
    new Date().toISOString().replace("T", "_").replace(/:/g, "-").replace(/\..+/, "");

  // ─────────────────────────────────────────────────────────────────────────
  //  XLSX EXPORT
  // ─────────────────────────────────────────────────────────────────────────
  const downloadXLSX = (results, errors) => {
    const ws1 = XLSX.utils.aoa_to_sheet([
      ["Creator Name", "Location", "Followers", "Engagement",
       "Instagram URL", "Instagram Username", "TikTok URL", "TikTok Username"],
      ...results.map((d) => [
        d.creatorName, d.location, d.followers, d.engagement,
        d.instagramURL, d.instagramUsername, d.tiktokURL, d.tiktokUsername,
      ]),
    ]);
    ws1["!cols"] = [
      { wch: 28 }, { wch: 20 }, { wch: 14 }, { wch: 14 },
      { wch: 45 }, { wch: 28 }, { wch: 45 }, { wch: 28 },
    ];
    const ws2 = XLSX.utils.aoa_to_sheet([
      ["Row #", "Creator Name", "Location", "Reason"],
      ...errors.map((e) => [e.rowIndex + 1, e.creatorName, e.location, e.reason]),
    ]);
    ws2["!cols"] = [{ wch: 8 }, { wch: 28 }, { wch: 20 }, { wch: 45 }];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws1, "Influencers");
    if (errors.length) XLSX.utils.book_append_sheet(wb, ws2, "Skipped");

    const fname = `influencers_${safeTimestamp()}.xlsx`;
    XLSX.writeFile(wb, fname);
    log(`Downloaded: ${fname}`, "success");
  };

  // ─────────────────────────────────────────────────────────────────────────
  //  AUTO-RESUME
  // ─────────────────────────────────────────────────────────────────────────
  const saveResume  = (nextIdx, results, seenKeys, errors) => {
    try { sessionStorage.setItem(RESUME_KEY, JSON.stringify({ nextIdx, results, seenKeys: [...seenKeys], errors })); } catch (_) {}
  };
  const loadResume  = () => { try { const r = sessionStorage.getItem(RESUME_KEY); return r ? JSON.parse(r) : null; } catch (_) { return null; } };
  const clearResume = () => { try { sessionStorage.removeItem(RESUME_KEY); } catch (_) {} };

  // ─────────────────────────────────────────────────────────────────────────
  //  MAIN
  // ─────────────────────────────────────────────────────────────────────────
  log("Script v3.3 started. [Fix1: ER column] [Fix2: No isPanelOpen dependency]");
  await loadSheetJS();

  const { followersIdx, engagementIdx } = detectColumnIndices();

  log(`Loading up to ${MAX_ROWS} rows…`);
  const loaded = await tryLoadMoreRows(MAX_ROWS);
  log(`${loaded} row(s) available.`);

  const allRows = Array.from(document.querySelectorAll("tbody tr"));
  if (!allRows.length) { log("No rows. Aborting.", "error"); return; }

  const rowsToProcess = allRows.slice(0, MAX_ROWS);
  log(`Processing ${rowsToProcess.length} row(s).`);

  const resume  = loadResume();
  let startIdx  = 0;
  let results   = [];
  let seenKeys  = new Set();
  let errors    = [];

  if (resume) {
    log(`Resuming from row ${resume.nextIdx + 1}. To restart: sessionStorage.removeItem("${RESUME_KEY}")`, "warn");
    startIdx = resume.nextIdx;
    results  = resume.results  || [];
    seenKeys = new Set(resume.seenKeys || []);
    errors   = resume.errors   || [];
    if (startIdx >= rowsToProcess.length) {
      log("All rows done. Exporting.", "warn");
      downloadXLSX(results, errors);
      clearResume();
      return;
    }
  }

  // ── Pre-run: close any lingering panel ─────────────────────────────────
  log("Pre-run panel close…");
  await closePanel();

  const startTime = Date.now();

  for (let i = startIdx; i < rowsToProcess.length; i++) {

    // ── Progress % + ETA ───────────────────────────────────────────────────
    const done = i - startIdx;
    if (done > 0) {
      const elapsed = (Date.now() - startTime) / 1000;
      const eta     = Math.ceil(((rowsToProcess.length - i) / (done / elapsed)));
      const pct     = Math.round((i / rowsToProcess.length) * 100);
      log(`Progress: ${i}/${rowsToProcess.length} (${pct}%) | ETA: ${eta}s`, "progress");
    }

    let freshRows = document.querySelectorAll("tbody tr");
    let freshRow  = freshRows[i] || rowsToProcess[i];
    let meta      = scrapeRowMeta(freshRow, followersIdx, engagementIdx);
    log(`[${i + 1}/${rowsToProcess.length}] "${meta.creatorName || "(no name)"}"`);

    // ── ✅ FIX 2: Click row → fixed wait → scrape ─────────────────────────
    //  Old logic waited for isPanelOpen() which was broken.
    //  New logic: just click, wait for animation, then let scrapePanel()
    //  handle the wait for social links internally (4s timeout).
    //  No isPanelOpen() needed anywhere in this flow.

    freshRow.scrollIntoView({ block: "center", behavior: "auto" });
    await sleep(SCROLL_WAIT);
    freshRow.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    log(`Row ${i + 1} — clicked, waiting for panel…`);
    await sleep(PANEL_OPEN_WAIT);   // wait for panel slide-in animation

    // ── Scrape social links ───────────────────────────────────────────────
    let panelData = { instagramURL: "", instagramUsername: "", tiktokURL: "", tiktokUsername: "" };
    try {
      panelData = await scrapePanel();
      log(`Row ${i + 1} — Scraped ✓ | IG: ${panelData.instagramUsername || "—"} | TT: ${panelData.tiktokUsername || "—"}`, "success");
    } catch (err) {
      const reason = `Scrape error: ${err.message}`;
      log(`Row ${i + 1} — ${reason}`, "error");
      dumpPanelHTML(i + 1);
      errors.push({ rowIndex: i, creatorName: meta.creatorName, location: meta.location, reason });
    }

    // ── Dedup ─────────────────────────────────────────────────────────────
    const dedupKey = panelData.instagramURL || panelData.tiktokURL || `${meta.creatorName}|${meta.location}`;
    if (seenKeys.has(dedupKey)) {
      log(`Row ${i + 1} — Duplicate, skipping.`, "warn");
      errors.push({ rowIndex: i, creatorName: meta.creatorName, location: meta.location, reason: "Duplicate" });
    } else {
      seenKeys.add(dedupKey);
      results.push({ ...meta, ...panelData });
    }

    // ── Close panel (Escape + X button fallback) ──────────────────────────
    await closePanel();

    // ── Checkpoint ───────────────────────────────────────────────────────
    saveResume(i + 1, results, seenKeys, errors);

    // ── GC ────────────────────────────────────────────────────────────────
    freshRow = null; freshRows = null; meta = null;

    await sleep(CLICK_DELAY);
  }

  clearResume();
  log(`Done. ${results.length} saved | ${errors.length} skipped | ${Math.round((results.length / rowsToProcess.length) * 100)}% success.`, "success");
  if (!results.length) { log("No data to export.", "warn"); return; }
  downloadXLSX(results, errors);
})();
