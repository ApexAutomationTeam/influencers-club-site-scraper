// ================================================================
//  influencers.club — AUTO SCRAPER v5.0  (Click-Based, No CORS)
//  Paste in Console → floating panel → click START
//  Auto-clicks "Unlock next 10" button → intercepts responses
//  STOP button → auto-downloads Excel with all captured data
// ================================================================
(async () => {

  // Remove old panel if exists
  document.getElementById("__ic2_panel")?.remove();

  const SHEETJS_CDN = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";
  const CLICK_DELAY = 2500; // ms between clicks

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ── SheetJS ──────────────────────────────────────────────────
  const loadSheetJS = () => new Promise((resolve, reject) => {
    if (typeof XLSX !== "undefined") { resolve(); return; }
    const s = document.createElement("script");
    s.src = SHEETJS_CDN;
    s.onload = resolve;
    s.onerror = () => reject(new Error("SheetJS load failed"));
    document.head.appendChild(s);
  });

  // ── Data store ───────────────────────────────────────────────
  const capturedResults = [];
  const seenUIDs        = new Set();
  let   _STOP           = false;
  let   _RUNNING        = false;
  let   clickCount      = 0;

  const addResults = (data) => {
    if (!data || !Array.isArray(data.results)) return 0;
    let added = 0;
    for (const r of data.results) {
      const uid = r.creator_uid
        || (r.instagram?.full_name + "|" + r.location)
        || (r.tiktok?.full_name   + "|" + r.location);
      if (!uid || seenUIDs.has(uid)) continue;
      seenUIDs.add(uid);
      capturedResults.push(r);
      added++;
    }
    return added;
  };

  // ── Intercept fetch (capture only, no replay) ─────────────────
  const _origFetch = window.fetch.bind(window);
  window.fetch = async function (input, init) {
    const url = (typeof input === "string" ? input : input?.url) ?? "";
    const res = await _origFetch(input, init);
    if (url.includes("preview-filter")) {
      res.clone().json().then(d => {
        const added = addResults(d);
        if (added > 0) updateUI();
      }).catch(() => {});
    }
    return res;
  };

  // ── Intercept XHR (capture only) ─────────────────────────────
  const _origOpen = XMLHttpRequest.prototype.open;
  const _origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, url) {
    this._xhrURL = url || "";
    return _origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    if (this._xhrURL?.includes("preview-filter")) {
      this.addEventListener("load", function () {
        try {
          const d = JSON.parse(this.responseText);
          const added = addResults(d);
          if (added > 0) updateUI();
        } catch (_) {}
      });
    }
    return _origSend.apply(this, arguments);
  };

  // ── Find unlock button ────────────────────────────────────────
  const getUnlockBtn = () =>
    Array.from(document.querySelectorAll("button"))
      .find(b => b.textContent.trim().startsWith("Unlock the next") && !b.disabled);

  // ════════════════════════════════════════════════════════════
  //  FLOATING UI
  // ════════════════════════════════════════════════════════════
  const panel = document.createElement("div");
  panel.id = "__ic2_panel";
  panel.innerHTML = `
    <style>
      #__ic2_panel {
        position:fixed; top:18px; right:18px; z-index:999999;
        width:305px; background:#1a1a2e; border:1.5px solid #4fc3f7;
        border-radius:14px; box-shadow:0 8px 32px rgba(0,0,0,.6);
        font-family:'Segoe UI',sans-serif; color:#eee;
        user-select:none; overflow:hidden;
      }
      #__ic2_hdr {
        background:linear-gradient(135deg,#0d47a1,#1565c0);
        padding:11px 16px; display:flex; align-items:center;
        justify-content:space-between; cursor:move;
      }
      #__ic2_hdr span { font-size:13px; font-weight:700; color:#fff; letter-spacing:.5px; }
      #__ic2_close { cursor:pointer; color:#90caf9; font-size:17px; background:none; border:none; line-height:1; }
      #__ic2_body { padding:14px 16px; }

      #__ic2_badge {
        display:inline-block; padding:3px 10px; border-radius:20px;
        font-size:11px; font-weight:700; margin-bottom:10px;
        text-transform:uppercase; letter-spacing:.5px;
      }
      .b-wait { background:#1a237e; color:#90caf9; }
      .b-run  { background:#1b5e20; color:#a5d6a7; }
      .b-stop { background:#b71c1c; color:#ef9a9a; }
      .b-done { background:#004d40; color:#80cbc4; }

      #__ic2_stats {
        background:#0d1117; border-radius:8px; padding:8px 12px;
        margin-bottom:12px; font-size:12px; line-height:2;
      }
      #__ic2_stats b { color:#4fc3f7; }

      #__ic2_prog_wrap {
        margin-bottom:10px; background:#0d1117; border-radius:6px;
        height:6px; overflow:hidden; display:none;
      }
      #__ic2_prog_bar {
        height:100%; background:linear-gradient(90deg,#4fc3f7,#1976d2);
        width:0%; transition:width .4s; border-radius:6px;
      }

      #__ic2_lim_row {
        display:flex; align-items:center; gap:8px;
        margin-bottom:12px; font-size:12px;
      }
      #__ic2_lim_row label { color:#90a4ae; white-space:nowrap; }
      #__ic2_limit {
        flex:1; background:#0d1117; border:1px solid #4fc3f7;
        border-radius:6px; color:#eee; padding:4px 8px;
        font-size:12px; outline:none;
      }

      #__ic2_btns { display:flex; gap:8px; }
      .ic2btn {
        flex:1; padding:9px 0; border:none; border-radius:8px;
        font-size:12px; font-weight:700; cursor:pointer;
        transition:opacity .2s; letter-spacing:.3px;
      }
      .ic2btn:hover    { opacity:.85; }
      .ic2btn:disabled { opacity:.35; cursor:not-allowed; }
      #__ic2_start  { background:linear-gradient(135deg,#43a047,#1b5e20); color:#fff; }
      #__ic2_stop   { background:linear-gradient(135deg,#e53935,#b71c1c); color:#fff; }
      #__ic2_export { background:linear-gradient(135deg,#1976d2,#0d47a1); color:#fff; }

      #__ic2_log {
        background:#0d1117; border-radius:8px; padding:8px 10px;
        margin-top:10px; font-size:11px; color:#90a4ae;
        max-height:95px; overflow-y:auto;
        font-family:monospace; line-height:1.5;
      }
    </style>

    <div id="__ic2_hdr">
      <span>🕷 IC Auto Scraper v5</span>
      <button id="__ic2_close">✕</button>
    </div>

    <div id="__ic2_body">
      <div id="__ic2_badge" class="b-wait">⏳ Ready</div>

      <div id="__ic2_stats">
        👤 Captured: <b id="__ic2_count">0</b> creators<br>
        🖱 Clicks: <b id="__ic2_clicks">0</b><br>
        💳 Credits: <b id="__ic2_credits">—</b>
      </div>

      <div id="__ic2_prog_wrap"><div id="__ic2_prog_bar"></div></div>

      <div id="__ic2_lim_row">
        <label>Max Creators:</label>
        <select id="__ic2_limit">
          <option value="50">50</option>
          <option value="100">100</option>
          <option value="200" selected>200</option>
          <option value="500">500</option>
          <option value="1000">1000</option>
          <option value="9999">All (max)</option>
        </select>
      </div>

      <div id="__ic2_btns">
        <button class="ic2btn" id="__ic2_start">▶ START</button>
        <button class="ic2btn" id="__ic2_stop"   disabled>⛔ STOP</button>
        <button class="ic2btn" id="__ic2_export" disabled>⬇ EXPORT</button>
      </div>

      <div id="__ic2_log">✓ Ready — click START to begin auto scraping.</div>
    </div>
  `;
  document.body.appendChild(panel);

  const ui = {
    badge:    panel.querySelector("#__ic2_badge"),
    count:    panel.querySelector("#__ic2_count"),
    clicks:   panel.querySelector("#__ic2_clicks"),
    credits:  panel.querySelector("#__ic2_credits"),
    progWrap: panel.querySelector("#__ic2_prog_wrap"),
    progBar:  panel.querySelector("#__ic2_prog_bar"),
    limit:    panel.querySelector("#__ic2_limit"),
    btnStart: panel.querySelector("#__ic2_start"),
    btnStop:  panel.querySelector("#__ic2_stop"),
    btnExport:panel.querySelector("#__ic2_export"),
    log:      panel.querySelector("#__ic2_log"),
    close:    panel.querySelector("#__ic2_close"),
    hdr:      panel.querySelector("#__ic2_hdr"),
  };

  // ── Drag ──────────────────────────────────────────────────────
  let dx=0, dy=0, drag=false;
  ui.hdr.addEventListener("mousedown", e => {
    drag=true; dx=e.clientX-panel.offsetLeft; dy=e.clientY-panel.offsetTop;
  });
  document.addEventListener("mousemove", e => {
    if (drag) {
      panel.style.left  = e.clientX-dx+"px";
      panel.style.top   = e.clientY-dy+"px";
      panel.style.right = "auto";
    }
  });
  document.addEventListener("mouseup", () => { drag=false; });

  // ── Close ─────────────────────────────────────────────────────
  ui.close.addEventListener("click", () => { _STOP=true; panel.remove(); });

  // ── Helpers ───────────────────────────────────────────────────
  const logMsg = msg => {
    ui.log.innerHTML += `<div>${msg}</div>`;
    ui.log.scrollTop = ui.log.scrollHeight;
  };

  const setBadge = (cls, txt) => {
    ui.badge.className = cls;
    ui.badge.textContent = txt;
  };

  const updateUI = (max) => {
    ui.count.textContent  = capturedResults.length;
    ui.clicks.textContent = clickCount;
    if (capturedResults.length > 0) ui.btnExport.disabled = false;
    if (max && max > 0) {
      const pct = Math.min(100, Math.round(capturedResults.length / max * 100));
      ui.progBar.style.width = pct + "%";
    }
  };

  // ── EXPORT ────────────────────────────────────────────────────
  const fmt      = v  => (v  != null ? v  : "");
  const bool     = v  => (v === true ? "Yes" : v === false ? "No" : "");
  const pctFmt   = v  => (v  != null ? v.toFixed(2)+"%" : "");
  const cqi      = v  => (v  != null ? v.toFixed(3) : "");
  const growth   = (obj, key="creator_follower_growth") => {
    const g = (obj?.[key] || obj?.creator_follower_growth)?.["3_months_ago"];
    if (g == null) return "";
    return (g >= 0 ? "+" : "") + g.toFixed(2) + "%";
  };
  const flatLinks = arr => (arr||[]).flat().filter(x=>x&&typeof x==="string").join(" | ");

  const mapResult = r => {
    const ig=r.instagram||{}, tt=r.tiktok||{}, yt=r.youtube||{}, tw=r.twitter||{};
    const name   = ig.full_name||tt.full_name||yt.title||r.first_name||"";
    const ytURL  = yt.custom_url ? `https://youtube.com/${yt.custom_url}` : "";
    const allLinks = [flatLinks(r.external_urls), flatLinks(r.other_links)].filter(Boolean).join(" | ");
    const hashtags = (r.hashtags||[]).map(h=>"#"+h).join(", ");
    return {
      "Creator Name":       fmt(name),
      "Location":           fmt(r.location),
      "Total Reach":        fmt(r.total_reach),
      "Engagement %":       pctFmt(r.engagement_percent),
      "Is Verified":        bool(r.is_verified),
      "Has Email":          bool(r.has_email),
      "Speaking Language":  fmt(r.speaking_language),
      "IG Full Name":       fmt(ig.full_name),
      "IG Followers":       fmt(ig.follower_count),
      "IG Growth (3mo)":    growth(ig),
      "IG Location":        fmt(ig.location_unified),
      "IG Verified":        bool(ig.is_verified),
      "IG CQI":             cqi(ig.cqi_value),
      "TT Full Name":       fmt(tt.full_name),
      "TT Handle":          fmt(tt.first_name),
      "TT Followers":       fmt(tt.follower_count),
      "TT Growth (3mo)":    growth(tt),
      "TT Region":          fmt(tt.region),
      "TT CQI":             cqi(tt.cqi_value),
      "YT Channel":         fmt(yt.title),
      "YT URL":             ytURL,
      "YT Subscribers":     fmt(yt.subscriber_count),
      "YT Growth (3mo)":    growth(yt,"creator_subscriber_growth"),
      "YT CQI":             cqi(yt.cqi_value),
      "Twitter Name":       fmt(tw.full_name),
      "Twitter Followers":  fmt(tw.follower_count),
      "External Links":     allLinks,
      "Hashtags":           hashtags,
      "Creator UID":        fmt(r.creator_uid),
      "Profile Picture URL":fmt(r.profile_picture),
    };
  };

  const safeTS = () =>
    new Date().toISOString().replace("T","_").replace(/:/g,"-").replace(/\..+/,"");

  const doExport = () => {
    if (!capturedResults.length) { logMsg("❌ No data to export."); return; }
    try {
      const rows    = capturedResults.map(mapResult);
      const headers = Object.keys(rows[0]);
      const ws      = XLSX.utils.aoa_to_sheet([
        headers,
        ...rows.map(r => headers.map(h => r[h] ?? ""))
      ]);
      ws["!cols"] = headers.map(h => ({ wch: Math.max(h.length+4, 16) }));
      const wb  = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Influencers");
      const fname = `influencers_${safeTS()}.xlsx`;
      XLSX.writeFile(wb, fname);
      logMsg(`⬇ Downloaded: ${fname} (${capturedResults.length} creators)`);
    } catch(e) {
      logMsg(`❌ Export error: ${e.message}`);
    }
  };

  ui.btnExport.addEventListener("click", doExport);

  // ── STOP ──────────────────────────────────────────────────────
  ui.btnStop.addEventListener("click", () => {
    _STOP = true;
    setBadge("b-stop", "⛔ Stopping…");
    logMsg("⛔ Stop pressed — will download when loop ends…");
    ui.btnStop.disabled = true;
  });

  // ── START ─────────────────────────────────────────────────────
  ui.btnStart.addEventListener("click", async () => {
    if (_RUNNING) { logMsg("⚠ Already running!"); return; }
    _STOP    = false;
    _RUNNING = true;
    clickCount = 0;

    const maxCreators = parseInt(ui.limit.value, 10);

    ui.btnStart.disabled  = true;
    ui.btnStop.disabled   = false;
    ui.progWrap.style.display = "block";
    setBadge("b-run", "🔄 Scraping…");
    logMsg(`▶ Started — target: ${maxCreators} creators`);

    let noNewStreak = 0;

    while (!_STOP && capturedResults.length < maxCreators) {

      const prevCount = capturedResults.length;

      // Find the unlock button
      const btn = getUnlockBtn();

      if (!btn) {
        // Button not visible — wait
        logMsg(`⏳ Unlock button not found, waiting…`);
        await sleep(2000);
        noNewStreak++;
        if (noNewStreak > 8) {
          logMsg("✅ No more unlock button — all results scraped!");
          break;
        }
        continue;
      }

      // Click it!
      btn.click();
      clickCount++;
      updateUI(maxCreators);
      logMsg(`🖱 Click #${clickCount} — waiting for response…`);

      // Wait up to 10s for new data
      let waited = 0;
      while (waited < 10000) {
        await sleep(400);
        waited += 400;
        if (capturedResults.length > prevCount) break;
        if (_STOP) break;
      }

      const added = capturedResults.length - prevCount;
      if (added > 0) {
        noNewStreak = 0;
        updateUI(maxCreators);
        logMsg(`✅ +${added} new (total: ${capturedResults.length})`);
      } else {
        noNewStreak++;
        logMsg(`⚠ No new data after click #${clickCount} (streak: ${noNewStreak})`);
        if (noNewStreak >= 3) {
          logMsg("✅ No more results available — done!");
          break;
        }
      }

      // Polite delay before next click
      await sleep(CLICK_DELAY);
    }

    _RUNNING = false;
    ui.btnStart.disabled  = false;
    ui.btnStop.disabled   = true;

    const finalMsg = `${capturedResults.length} creators captured`;
    if (_STOP) setBadge("b-stop", `⛔ Stopped — ${finalMsg}`);
    else       setBadge("b-done", `✅ Done — ${finalMsg}`);

    logMsg(`✅ Finished! ${finalMsg}`);

    // Auto-export on finish or stop
    if (capturedResults.length > 0) {
      logMsg("⬇ Auto-downloading Excel…");
      doExport();
    }
  });

  // ── Init ──────────────────────────────────────────────────────
  await loadSheetJS();
  logMsg("✓ SheetJS ready. Click START to auto-scrape!");

})();
